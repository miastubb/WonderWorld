My rainy days project, the transition from design to first time code.
been and still is a lot of bumps in the road but i'm learning something new every day.
Who said an old dog can't learn new tricks!
